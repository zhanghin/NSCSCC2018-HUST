#include "flash.h"



//this function is not included in header file.
static unsigned char SPI_Send_Byte(unsigned char data)
{
    // ��鲢�ȴ�TX������Ϊ��
    while((*READ_IO(SPI_AXI_LITE + sr) & 0x4)==0);
    
    // ������Ϊ�պ��򻺳���д��Ҫ���͵��ֽ�����
    *WRITE_IO(SPI_AXI_LITE + dtr) = data;	

    // ��鲢�ȴ�RX������Ϊ�ǿ�
    while((*READ_IO(SPI_AXI_LITE + sr) & 0x1)==1);

    // ���ݷ�����ϣ���RX����������flash���ص����� 	
    return *READ_IO(SPI_AXI_LITE + drr); 
}



void necessaryOperationBeforeReadBytes(unsigned int address)
{
	*WRITE_IO(SPI_AXI_LITE + srr) = 0x0000000a;		//software reset 
	*WRITE_IO(SPI_AXI_LITE + cr) = 0x164;			//clear Tx and Rx 
	*WRITE_IO(SPI_AXI_LITE + cr) = 0x6;				//enable spi and master mode
	FLASH_SPI_CS_LOW;								// �͵�ƽƬѡ��Ч��SPIͨѶ��ʼ
	SPI_Send_Byte(FAST_READ_CMD);                    // ���Ͷ�ȡIDָ��
	SPI_Send_Byte((unsigned char) (address >>16));
	SPI_Send_Byte((unsigned char) (address >>8));
	SPI_Send_Byte((unsigned char) (address ));
	SPI_Send_Byte(Dummy_Byte);
	return;
}

unsigned int readFourBytes()
{
	unsigned int data4Bytes = 0x0;
	unsigned int data = 0x0;
	int i = 0;
	for( ; i < 4 ; i++)
	{
		data = (unsigned int) SPI_Send_Byte(Dummy_Byte);
		data4Bytes = data4Bytes | data << (i * 8);//carefull here. Do not modify the endianess.
		data = 0x0;
	}

	return data4Bytes;
}

unsigned short readTwoBytes (void)
{
	unsigned char data1 = 0x0;
	unsigned char data2 = 0x0;
	data1 =  SPI_Send_Byte(Dummy_Byte);
	data2 =  SPI_Send_Byte(Dummy_Byte);
	unsigned short data2Bytes = data1 | data2 << 8;//carefull here. Do not modify the endianess.
	return data2Bytes;
}

unsigned char readOneByte (void)
{
	return SPI_Send_Byte(Dummy_Byte);
}

void operationsAfterReadBytes()
{
	FLASH_SPI_CS_HIGH;                           // ֹͣSPIͨѶ
	return;	
}


void skipNBytes(int n)
{
	int cnt = 0;
	for(cnt = 0; cnt < n ; cnt ++)
	{
		readOneByte();
	}
	return;
}



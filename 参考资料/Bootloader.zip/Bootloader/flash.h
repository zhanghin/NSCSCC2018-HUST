/*
 * uart.h
 *
 *  Created on: April 5, 2018
 *      Author: Han XIAO
 */
#ifndef FLASH_H
#define FLASH_H
#include "fpga.h"   /***we need WRITE_IO macro which is defined in fpga.h***/

#define SPI_AXI_LITE  0xB4A00000
#define READ_ADDR 		0x400000

#define Dummy_Byte    0x0

/* FLASH Operations */
#define READ_CMD                             0x03
#define FAST_READ_CMD                        0x0B
#define DUAL_INOUT_FAST_READ_CMD             0xBB
#define QUAD_INOUT_FAST_READ_CMD             0xEB
#define WRITE_ENABLE_CMD                     0x06
#define WRITE_DISABLE_CMD                    0x04

//SPI REG
#define srr 0x40      //Software reset register
#define cr 0x60       //SPI control register
#define sr 0x64       //SPI status register
#define dtr 0x68      //SPI data transmit register. A single register or a FIFO
#define drr 0x6c      //SPI data receive register. A single register or a FIFO
#define ssr 0x70      //SPI Slave select register
#define tor 0x74        //SPI Transmit FIFO Occupancy Register
#define ror 0x78      //Receive FIFO occupancy register


#define FLASH_SPI_CS_LOW  *WRITE_IO(SPI_AXI_LITE + ssr) = 0x0
#define FLASH_SPI_CS_HIGH  *WRITE_IO(SPI_AXI_LITE + ssr) = 0x1

//functions

void necessaryOperationBeforeReadBytes (unsigned int address);
unsigned int readFourBytes (void);
unsigned short readTwoBytes (void);
unsigned char readOneByte (void);
void operationsAfterReadBytes (void);

void skipNBytes(int n);
#endif /*FLASH_H*/

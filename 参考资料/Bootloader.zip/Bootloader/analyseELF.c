#include "flash.h"
#include "analyseELF.h"

#define convert2FlashAddress(x) (READ_ADDR + x)


void elfGetEntryAddress(unsigned int *entryAddress)
{
	necessaryOperationBeforeReadBytes(convert2FlashAddress(0x18));
	(*entryAddress) = readFourBytes();
	operationsAfterReadBytes();
	return;
}


void elfGetTextAndDataSectionInformation(unsigned int *textVirtualAddress, unsigned int *textFlashAddress, unsigned int *textLength, unsigned int *dataVirtualAddress, unsigned int *dataFlashAddress, unsigned int *dataLength)
{	//We assume the ELF is 32 bits address mode and little endian.
 	//There are NO error handling when dealing with 64 bits address mode or big endian.
	int SectionHeaderAmount = -1;
	necessaryOperationBeforeReadBytes(convert2FlashAddress(0x30));
	SectionHeaderAmount = readTwoBytes();
	operationsAfterReadBytes();

	unsigned int sectionHeaderFlashAddress = 0;
	necessaryOperationBeforeReadBytes(convert2FlashAddress(0x20));
	unsigned int tempOffset = readFourBytes();
	operationsAfterReadBytes();
	necessaryOperationBeforeReadBytes(convert2FlashAddress(tempOffset));
	int cnt = 0;
	int dataOrTextSection = 0;
	for(cnt = 0 ; cnt < SectionHeaderAmount ; cnt ++)
	{
		if(dataOrTextSection == 2)
		{
			break;
		}
		skipNBytes(8);
		unsigned int sh_flags = readFourBytes();//sh_flags : this terminology comes from ELF format specification.
		if(sh_flags == 0x1 + 0x2)
		{//this is data section because it is writable and allocatable
			dataOrTextSection++;
			*dataVirtualAddress = readFourBytes();
			*dataFlashAddress = convert2FlashAddress( readFourBytes() );
			*dataLength = readFourBytes();
			skipNBytes(16);
		}
		else if(sh_flags == 0x2 + 0x4)
		{//this is text section because it is allocatable and executable
			dataOrTextSection++;
			*textVirtualAddress = readFourBytes();
			*textFlashAddress = convert2FlashAddress( readFourBytes() );
			*textLength = readFourBytes();
			skipNBytes(16);
		}
		else
		{//this is neither text section nor data section
			skipNBytes(28);//note : this is decimal , not hex.
		}
	}
	operationsAfterReadBytes();// do not forget to "close" the "file".
	return;
}

/*
 * uart.h
 *
 *  Created on: April 4, 2018
 *      Author: Han XIAO
 */

#ifndef UART_H
#define UART_H
//remember to initialize the interrupt for the uart.

#define UART_BASE 0xB0401000	//With 1000 offset that axi_uart16550 has
#define rbr		0*4
#define ier		1*4
#define fcr		2*4
#define lcr		3*4
#define mcr		4*4
#define lsr		5*4
#define msr		6*4
#define scr		7*4

#define thr		rbr
#define iir		fcr
#define dll		rbr
#define dlm		ier

void delay();
void uart_init(void);
void uart_outbyte(char c);
void uart_print(const char *ptr);
void uart_printHex(unsigned int data);
#endif /* UART_H */


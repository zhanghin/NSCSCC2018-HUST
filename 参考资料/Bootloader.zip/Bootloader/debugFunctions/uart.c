/*
 * uart.c
 *
 *  Created on: April 5 2018
 *      Author: Han XIAO
 */
#include "uart.h"

#define READ_IO(addr)  (volatile unsigned int *)(addr)
#define WRITE_IO(addr) (volatile unsigned int *)(addr)

void delay() {
	volatile unsigned int j;
	for (j = 0; j < (10000); j++) ;	// delay 
}

void uart_init(void)
{
	*WRITE_IO(UART_BASE + lcr) = 0x00000080; // LCR[7]  is 1
	delay();
	*WRITE_IO(UART_BASE + dll) = 27; // DLL msb. 115200 at 50MHz. Formula is Clk/16/baudrate. From axi_uart manual.
	delay();
	*WRITE_IO(UART_BASE + dlm) = 0x00000000; // DLL lsb.
	delay();
	*WRITE_IO(UART_BASE + lcr) = 0x00000003; // LCR register. 8n1 parity disabled
	delay();
	*WRITE_IO(UART_BASE + ier) = 0x00000000; // IER register. disable interrupts
	delay();	
	*WRITE_IO(UART_BASE + ier) = 0x00000001; // IER register. Enables Receiver Line Status and Received Data Interrupts
	delay();
	return;
}

void uart_outbyte(char c) {
	*WRITE_IO(UART_BASE + thr) = (unsigned int) c;
	delay( );
}

void uart_print(const char *ptr){
	while (*ptr) {
		uart_outbyte (*ptr);
		ptr++;
	}
}

static const char * table = "0123456789ABCDEF";
void uart_printHex(unsigned int data)
{
	char tmp[9];
	tmp[8] = 0;//tmp[8] = '\0';
	int cnt = 0;
	for (cnt = 7 ; cnt >= 0 ; cnt-- )
	{
		tmp[cnt] = table[ data & 0xf ];
		data = data >> 4;
	}	
	uart_print(tmp);
	return;
}

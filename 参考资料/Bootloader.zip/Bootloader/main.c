#include "flash.h"
#include "fpga.h"
#define debug
#ifdef debug
#include "debugFunctions/uart.h"
#endif

//extern struct flash flashInstance;
//struct flash *pFlashInstance = &flashInstance;

int main()
{
#ifdef debug
	uart_init();
	uart_print("serial port is working during the boot process\r\n");
#endif
	unsigned int entryAddress = 0;
	elfGetEntryAddress(&entryAddress);
#ifdef debug
	uart_print("entryAddress");
	uart_printHex(entryAddress);
	uart_print("\r\n");
#endif

	//now we analysis the elf header.
	int textVirtualAddress = 0;
	int textFlashAddress = 0;
	int textLength = 0;
	int dataVirtualAddress = 0;
	int dataFlashAddress = 0;
	int dataLength = 0;
	elfGetTextAndDataSectionInformation(&textVirtualAddress,&textFlashAddress,&textLength,&dataVirtualAddress,&dataFlashAddress,&dataLength);
#ifdef debug
	uart_print("textVirtualAddress");
	uart_printHex(textVirtualAddress);
	uart_print("\r\n");
	uart_print("textFlashAddress");
	uart_printHex(textFlashAddress);
	uart_print("\r\n");
	uart_print("textLength");
	uart_printHex(textLength);
	uart_print("\r\n");
	uart_print("dataVirtualAddress");
	uart_printHex(dataVirtualAddress);
	uart_print("\r\n");
	uart_print("dataFlashAddress");
	uart_printHex(dataFlashAddress);
	uart_print("\r\n");
	uart_print("dataLength");
	uart_printHex(dataLength);
	uart_print("\r\n");
#endif


	textLength = textLength/4;//do the divide because we copy the section data 4 bytes by 4 bytes. See below.
	dataLength = dataLength/4;//do the divide because we copy the section data 4 bytes by 4 bytes. See below.
	int cnt = 0;
	unsigned int data = 0;
	//read the text section
	necessaryOperationBeforeReadBytes(textFlashAddress);
	for(cnt = 0 ; cnt < textLength ; cnt ++)
	{
		data = readFourBytes();
		*WRITE_IO(textVirtualAddress + cnt*4 ) = data; 
	}
	operationsAfterReadBytes();


	//read the data section
	necessaryOperationBeforeReadBytes(dataFlashAddress);
	for(cnt = 0 ; cnt < dataLength ; cnt ++)
	{
		data = readFourBytes();
		*WRITE_IO(dataVirtualAddress + cnt*4 ) = data; 
	}
	operationsAfterReadBytes();

	asm volatile("addu $t0, $0, %0;\n"
				 "jr $t0;\n"
				 "nop;\n"
				 "nop;\n"
				 :
				 :"r"(entryAddress)
				 :"t0"
				); 

#ifdef debug
	uart_print("never here!\r\n");
#endif
	return 0;
}

	//jump to the kernel entry point.
	/*asm ("addu $t0 ,$0, $0\r\n"
		"lui $t0 ,0x8000\r\n"
		"addiu $t0, 0x1000\r\n"
		"jr $t0\r\n"
		"nop\r\n"
		"nop");"addu $t0, $t0, %1\n"*/
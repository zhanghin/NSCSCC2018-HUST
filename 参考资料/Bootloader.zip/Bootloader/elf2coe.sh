#!/bin/sh
mips-sde-elf-objcopy -O binary FPGA_Ram.elf FPGA_Ram.bin
echo 'memory_initialization_radix=16;' > FPGA_Ram.coe
echo 'memory_initialization_vector= ' >> FPGA_Ram.coe
hexdump -v -e '1/4 "%08x\n"' FPGA_Ram.bin > FPGA_Ram_temp.coe
awk '$0=$0" 00000000 00000000 00000000 "' FPGA_Ram_temp.coe >> FPGA_Ram.coe
echo ';' >> FPGA_Ram.coe
rm FPGA_Ram_temp.coe
rm FPGA_Ram.bin

/*
 * uart.h
 *
 *  Created on: April 5, 2018
 *      Author: Han XIAO
 */
#ifndef FLASH_H
#define FLASH_H




/*These functions are implemented and used*/
void elfGetEntryAddress(unsigned int *entryAddress);
void elfGetTextAndDataSectionInformation(unsigned int *textVirtualAddress, unsigned int *textFlashAddress, unsigned int *textLength, unsigned int *dataVirtualAddress, unsigned int *dataFlashAddress, unsigned int *dataLength);



#endif /*FLASH_H*/

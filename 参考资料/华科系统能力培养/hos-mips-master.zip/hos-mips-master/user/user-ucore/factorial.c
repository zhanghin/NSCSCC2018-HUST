/* program name factorial.c 
 * recursively compute the factorial of an input number N, that is, N!
 * use this program to stress stack so as to generate user space fgfault
*/

#ifndef __UCORE_ENTRY_H__
#define __UCORE_ENTRY_H__

extern volatile int init_finished;

#endif

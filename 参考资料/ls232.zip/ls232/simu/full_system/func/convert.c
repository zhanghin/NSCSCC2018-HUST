#include <stdio.h>
#include <stdlib.h>

int main(void)
{
	FILE *in;
	FILE *out;
	FILE *out0, *out1, *out2, *out3;
	FILE *out4, *out5, *out6, *out7;

	FILE *out0_0;
	FILE *out1_0;
	FILE *out2_0;
	FILE *out3_0;
	FILE *out4_0;
	FILE *out5_0;
	FILE *out6_0;
	FILE *out7_0;
	
    int i,j,k;
	unsigned char mem[4];
	unsigned char mem_dspm[32];
    unsigned int  ch_mem;

    in  = fopen("godson_test.bin", "rb");
	out = fopen("rom0.vlog", "w");

	fprintf(out, "  @00\n");
	while(!feof(in)) {
	    if(fread(mem,1,4,in)!=4) {
            ch_mem = (mem[3] << 24) | (mem[2] << 16) | (mem[1] << 8) | mem[0];
            fprintf(out, "  %08x\n", ch_mem );
		break;
	     }
        ch_mem = (mem[3] << 24) | (mem[2] << 16) | (mem[1] << 8) | mem[0];
        fprintf(out, "  %08x\n", ch_mem );
        }
	fclose(in);
	fclose(out);


	in = fopen("godson_test.data", "rb");
	out0 = fopen("ram3.vlog", "w");
	out1 = fopen("ram2.vlog", "w");
	out2 = fopen("ram1.vlog", "w");
	out3 = fopen("ram0.vlog", "w");

	i = j = 0;
	fprintf(out0, "  @80000\n");
	fprintf(out1, "  @80000\n");
	fprintf(out2, "  @80000\n");
	fprintf(out3, "  @80000\n");
	while(!feof(in)) {
		if(fread(mem,1,4,in)!=4) {
			if(feof(in)) break;
			printf("Read binary file error \n");
			break;
		}
		fprintf(out0, "  %02x", mem[0]);
		fprintf(out1, "  %02x", mem[1]);
		fprintf(out2, "  %02x", mem[2]);
		fprintf(out3, "  %02x", mem[3]);
		i++;
		j+=4;
		if(i == 4) {
			i = 0;
			fprintf(out0, "\n");
			fprintf(out1, "\n");
			fprintf(out2, "\n");
			fprintf(out3, "\n");
		}
	}

	fclose(in);

	fclose(out0);
	fclose(out1);
	fclose(out2);
	fclose(out3);


}


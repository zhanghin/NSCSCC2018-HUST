//+-----------------------------------------------------------------------------
// This file contains Chinese characters. If you can not see them correctly, 
// please input command "set encoding=utf-8" in vim or open it with gedit. 
//------------------------------------------------------------------------------
目录结构：
---ls232/: gs232开源版本     -----20170120
      |---rtl/ : rtl源码,
      |---simu/: 仿真环境
            |---full_system/: 仿真func和ise运行脚本
            |        |---func/   : func编译目录 
            |        |---run_ise/: ise13.2创建的工程
            |---lib/        : sram的仿真模型文件存放目录
            |---testbench/  : 仿真模型顶层和axi slave虚拟设备
